# compiler2017-demo

please check `build.bash` and `semantic.bash`
